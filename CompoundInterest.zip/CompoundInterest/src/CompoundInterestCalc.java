
import java.text.NumberFormat;

public class CompoundInterestCalc {
	public static void main(String args[]) {
		int numMonths;
		int numCompoundPeriods, remainingMonths;
		double curValue, interestEarned, interestRate, fractionalTime, remainingInterest;
		int compoundType;
		/* Symbolic constants make code easier to read */
		final int MONTHLY = 0;
		final int YEARLY = 1;
		final int QUARTERLY = 2;
		
		/* Hardcode a few values -- these are the inputs to our calculation */
		curValue = 10000.00;
		compoundType = QUARTERLY;
		numMonths = 10;
		interestRate = 5.0;
		
		/* First find how many compounding periods we have */
		switch (compoundType) {
		case MONTHLY:
			numCompoundPeriods = numMonths;
			remainingMonths = 0; /* months left over */
			break;
		case QUARTERLY:
			numCompoundPeriods = numMonths/3;  /* a quarter is 3 months */
			remainingMonths = numMonths % 3;   /* months left over */
			break;
		case YEARLY:
			numCompoundPeriods = numMonths/12;  /* 12 months in a year */
			remainingMonths = numMonths % 12;
			break;
		default:
			System.out.println("Unknown compounding type");
			return;
		}
		
		interestRate = interestRate / 100.0;
		
		/* compute the money earned for each compounding period and add it to curValue  (current value) */
		for (int i=0; i<numCompoundPeriods; i++) {
			interestEarned = curValue * interestRate;
			curValue = curValue + interestEarned;
		}
		
		/* if there are months left over, calculate the interest for those remaining months */
		
		if (remainingMonths > 0) {
			fractionalTime = remainingMonths / 12.0;
			/*
			 * For left over months, you don't get interest for the full compounding period; you get a fraction of
			 * the full compounding interest. E.g. if 25 months with yearly compounding the
			 * loop above computed the interest for 24 months (2 years), but we still have
			 * one month left over. The fractional time remaining is 1/12. If 25 months with
			 * quarterly compounding there were 8 compounding periods computed above and
			 * we have one month left over. So the fractional time would be 1/12
			 */
			remainingInterest = curValue * interestRate * fractionalTime;
			curValue = curValue + remainingInterest;
		}
		
		System.out.println("New balance is: " + curValue);
		
		/* We can do one more improvement: use a NumberFormatter to produce a string containing two decimal places and a dollar sign */
		NumberFormat dollarFormatter = NumberFormat.getCurrencyInstance();
		System.out.println("New formatted balance is: " + dollarFormatter.format(curValue));
	}

}
